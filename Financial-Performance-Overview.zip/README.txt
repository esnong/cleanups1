Download Power BI templates and get latest updates from
https://metricalist.com


-------------

2020.09.01 - version 1.1.0

* Fix: Template background stretched

-------------

2020.03.01 - version 1.0.0

* Initial release